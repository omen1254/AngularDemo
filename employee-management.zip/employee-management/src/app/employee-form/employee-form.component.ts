import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css']
})
export class EmployeeFormComponent {
  @Input() employee: any;
  @Output() updated = new EventEmitter<any>();

  formSubmitted: boolean = false;

  updateEmployee(): void {
    this.formSubmitted = true;
    this.updated.emit(this.employee);
  }
}
