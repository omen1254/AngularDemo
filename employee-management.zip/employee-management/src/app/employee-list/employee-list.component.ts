import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employees: any[] = [];
  selectedEmployee: any = null;
  updatedEmployee: any = null;

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.employeeService.getEmployees().subscribe(data => {
      this.employees = data;
    });
  }

  openForm(emp: any): void {
    this.selectedEmployee = { ...emp };
  }

  onUpdate(updatedEmployee: any): void {
    this.employeeService
      .updateEmployee(updatedEmployee.id, updatedEmployee)
      .subscribe(() => {
        const index = this.employees.findIndex(e => e.id === updatedEmployee.id);
        this.employees[index] = updatedEmployee;
        
        this.selectedEmployee = null;
      });
      this.updatedEmployee = updatedEmployee;
  }
}
